magazines = [
  "https://flipboard.com/@thenewsdesk/the-latest-on-coronavirus-covid-19-t82no8kmz.rss",
  "https://flipboard.com/@dfletcher/india-tech-b2meqpd6z.rss",
  "https://flipboard.com/@thehindu/sportstarlive-rj3ttinvz.rss"
]

/** Caution: Do not write your logic in this file.
 * This file gets replaced during assessment with the original content that
 * we have for assessment. If you write your code in this file, you will end up deleting it in the assessment.
 * Uncomment the below lines to do local assessment
 */
magazines = [
  "https://assessment-rss.s3.ap-south-1.amazonaws.com/coronavirus.rss",
  "https://assessment-rss.s3.ap-south-1.amazonaws.com/india-tech.rss",
  "https://assessment-rss.s3.ap-south-1.amazonaws.com/sports-star.rss",
];
