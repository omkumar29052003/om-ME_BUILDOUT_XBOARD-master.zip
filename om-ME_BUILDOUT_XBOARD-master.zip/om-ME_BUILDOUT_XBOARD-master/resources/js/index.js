async function fetchingFeeds(element) {
    let url = `https://api.rss2json.com/v1/api.json?rss_url=${element}`;
    console.log(url);
    let response = await fetch(url);
    let data = await response.json();
    return data;
}
function carouselData(carouselInfoArr, index) {
    let carouselInner = document.getElementById(`accordion${index}`).querySelector(".carousel-inner");
    console.log(carouselInfoArr);    
    carouselInfoArr.forEach((news, indexNews) => {
        let carouselItem = document.createElement("div");
        if (indexNews == 0) {
            carouselItem.classList = `carousel-item active`;
        } else {
            carouselItem.className = `carousel-item`;
        }
      carouselItem.innerHTML = `<div class="card border-0">
                          <a href = "${news.link}" target = "_blank">
                          <img
                          src="${news.enclosure.link}"
                          class="card-img-top d-block w-100" alt="..." class = "activity-card-image"></a>
                          <div class="card-body">
                            <h4 class="card-title fw-bold">${news.title}</h4>
                            <div class="d-flex flex-row text-secondary">
                              <small><b>${news.author}</b></small>
                              <ul>
                                <li>
                                  <small><b>${news.pubDate}</b></small>
                                </li>
                              </ul>
                            </div>
                            <p class="card-text fs-6" style="font-weight: 500">
                              ${news.description}
                            </p>
                          </div>
                        </div >`;
      console.log(carouselItem);
      carouselInner.appendChild(carouselItem);
        
    });
}

function accordionCreation(accordionData, index) {
    let accordionItem = document.createElement("div");
    accordionItem.className = "accordion-item";
    accordionItem.id = `accordion${index}`
    let accordion = document.getElementById("accordionExample");
    accordionItem.innerHTML = `<h2 class="accordion-header" id="heading${index}">
                <button
                  class="accordion-button collapsed text-secondary"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#collapse${index}"
                  aria-expanded="false"
                  aria-controls="collapse${index}"
                >
                  ${accordionData.feed.title}
                </button>
              </h2>
              <div
                id="collapse${index}"
                class="accordion-collapse collapse"
                aria-labelledby="heading${index}"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                    <div
                    id="carouselExampleControls${index}"
                    class="carousel slide"
                    data-bs-ride="carousel"
                >
                    <div class="carousel-inner"></div>
                    <button
                      class="carousel-control-prev"
                      type="button"
                      data-bs-target="#carouselExampleControls${index}"
                      data-bs-slide="prev"
                    >
                      <span
                        class="carousel-control-prev-icon"
                        aria-hidden="true"
                      ></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button
                      class="carousel-control-next"
                      type="button"
                      data-bs-target="#carouselExampleControls${index}"
                      data-bs-slide="next"
                    >
                      <span
                        class="carousel-control-next-icon"
                        aria-hidden="true"
                      ></span>
                      <span class="visually-hidden">Next</span>
                </div>
                </div>
                </div>`;
    accordion.append(accordionItem);

  if (index == 0) {
    let button = document.querySelector(`.accordion-button`);
    button.classList = "accordion-button text-secondary";
    button.ariaExpanded = "true";
    let div = document.getElementById("collapse0");
    div.classList = "accordion-collapse collapse show";
  }

    carouselData(accordionData.items, index);
}

function rssFeeds(magazines) {
  magazines.forEach(async (element, index) => {
    let data = await fetchingFeeds(element);
    console.log(data);
    // accordionCreation(data);
    accordionCreation(data, index);
  });
}

rssFeeds(magazines);